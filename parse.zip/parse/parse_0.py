from tree import Tree, Leaf
from print_tree import print_tree

lexicon = {
        Leaf('N', 'cows'),
        Leaf('V', 'intimidate'),
        }

grammar = {
        'S':  [['NP', 'VP']],
        'NP': [['N']],
        'VP': [['V', 'NP']],
        }

def expand(tag):
    """Yield all trees rooted by tag."""

def expand_all(tags):
    """Yield all sequences of branches for a sequence of tags."""

for tree in expand('S'):
    print_tree(tree)
