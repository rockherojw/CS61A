import sys
from max_parse import *
from ucb import main

def words(t):
    """Yield the words in t."""
    if type(t) == Leaf:
        yield t.word
    else:
        for branch in t.branches:
            for word in words(branch):
                yield word

def extract_modal(t):
    """Delete and return the arg of a modal verb phrase."""
    if type(t) == Leaf:
        return None
    if len(t.branches) == 2 and t.branches[0].tag == 'MD':
        modal, clause = t.branches
        t.branches = [modal]
        return clause
    for b in t.branches:
        clause = extract_modal(b)
        if clause is not None:
            return clause
    return None

def yoda_transform(t):
    """Place the clause of a modal verb at the front."""
    clause = extract_modal(t)
    if clause is not None:
        return Tree(t.tag, [clause, Leaf(',', ',')] + t.branches)
    return t

@main
def run():
    for line in sys.stdin:
        tree = parse(line, 1, list)[0]
        print_tree(tree)
        yoda = yoda_transform(tree)
        print_tree(yoda)
        transformed = ' '.join(words(yoda))
        print('Yoda would say, "{}"'.format(transformed))
